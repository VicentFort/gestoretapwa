// src/plugins/vuetify.js
import 'vuetify/styles'
import { createVuetify } from 'vuetify'
import * as components from 'vuetify/components'
import * as directives from 'vuetify/directives'
import { aliases, mdi } from 'vuetify/iconsets/mdi'

export default createVuetify({
  
  components,
  directives,
  icons: {
    defaultSet: 'mdi',
    aliases,
    sets: {
      mdi,
    },
  },
  theme:{
  defaultTheme: 'gestoreta',
  themes: {
    gestoreta: {
      dark: false,
      colors: {
        background: '#FDFCF8',   // bone (era azul)
        surface:    '#FFFFFF',   // blanco puro (era naranja!)
        primary:    '#E35D33',   // terracotta — el acento, no el fondo
        secondary:  '#2D3E50',   // charcoal — para texto/acentos serios
        accent:     '#E35D33',
        error:      '#9E3026',
        success:    '#2F8F5A',
        warning:    '#C98A2E',
        info:       '#3B6FA0',
        // mantenemos los alias usados en tu código:
        ternary:    '#8B9E83',   // misma terracotta para no romper 
        quaternary: '#F4EDE2',   // cream para zonas suaves
        transaction:'#2F8F5A',
      },
      variables: {
        'border-color':   '#2D3E50',
        'border-opacity': 0.08,    // borde sutil, era 0.5
        'theme-on-background': '#2D3E50',
      },
    },
  },
},
defaults: {
  VCard:   { rounded: 'lg', elevation: 0, border: true, color: 'surface' },
  VBtn:    { rounded: 'lg', variant: 'flat', color:'secondary' },
  VTabs:   {
    bgColor: 'ternary',
    selectedClass: 'text-surface'

  },
  VChip:   { rounded: 'lg' },
  VSheet:  { rounded: 'lg' },
}
  
})